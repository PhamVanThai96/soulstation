from django.apps import AppConfig


class SolveproblemConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "solveproblem"

from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt


def members(request):
    template = loader.get_template('question_page.html')
    return HttpResponse(template.render())

QUESTIONS = [
    {
        'id': 1,
        'original': "What is the speed of light in a vacuum?",
        'translated': "Tốc độ ánh sáng trong chân không là bao nhiêu?"
    },
    {
        'id': 2,
        'original': "What is the Planck constant?",
        'translated': "Hằng số Planck là gì?"
    },
    {
        'id': 3,
        'original': "Explain the uncertainty principle.",
        'translated': "Giải thích nguyên lý bất định."
    },
]

def question_page(request):
    return render(request, 'question_page.html', {'question': QUESTIONS[0]})

@csrf_exempt
def get_next_question(request):
    if request.method == 'POST':
        current_id = int(request.POST.get('current_id', 1))
        next_index = current_id % len(QUESTIONS)
        return JsonResponse(QUESTIONS[next_index])

@csrf_exempt
def get_previous_question(request):
    if request.method == 'POST':
        current_id = int(request.POST.get('current_id', 1))
        prev_index = (current_id - 2) % len(QUESTIONS)
        return JsonResponse(QUESTIONS[prev_index])

